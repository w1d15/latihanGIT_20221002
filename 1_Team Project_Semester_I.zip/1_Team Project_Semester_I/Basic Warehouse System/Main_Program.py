import Module as Mod

def Main_Menu():
    Mod.Header()
    print("Main Menu")
    print()
    print("[1] - Inbound")    
    print("[2] - Outbound")
    print("[3] - Inventory")
    print("[0] - Log Out")
    print()
    Transaction_Code = input("Input Transaction Code : ")
    Tranasction_Selection(Transaction_Code)

def Tranasction_Selection(Transaction_Code):
    while True:
        if Transaction_Code == '1':
            Mod.Inbound()
            Main_Menu()
        elif Transaction_Code == '2':
            Mod.Outbound()
            Main_Menu()
        elif Transaction_Code == '3':
            Mod.Inventory_Menu()
        elif Transaction_Code == '0':
            print("Thank You".center(28))
            print("MEDICINE DEPARTMENT STORE".center(28))
            print("-"*28)
            Mod.Log_Out()
        else:
            print("Invalid Transaction Code")

Mod.Log_Out()