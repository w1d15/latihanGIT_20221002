
def Log_Out():
    Header()
    while True:
        LogIn_Username = input("Username : ")
        LogIn_Password = input("Password : ")
        LogIn = LogIn_Username + "|" + LogIn_Password
        with open ("Password.txt","r") as L:
            UserPassword = L.readline()
        if LogIn == UserPassword:
            import Main_Program
            Main_Program.Main_Menu()
        else:
            print("Invalid Username or Password")

def Inbound():
    Header()
    Description = input("Description : ")
    Quantity = int(input("Quantity    : "))

    with open("Inventory.txt", "r") as f:
        filedata = f.readlines()

    replace = ""
    line_number = 0
    count = 0
    f = open("Inventory.txt","r")
    file = f.read().split('\n')
    for i, line in enumerate(file):
        if Description in line:
            for b in file[i+1:i+2]:
                value = int(b)
                change = value + (Quantity)
                replace = b.replace(b, str(change))
                line_number = count
            count = i + 1      
    f.close()
    
    filedata[count] = replace + "\n"

    with open("Inventory.txt", "w") as f:
        for line in filedata:
            f.write(line)
    print("Inbound Completed")

def Outbound():
    Header()
    Description = input("Description : ")
    Quantity = int(input("Quantity    : "))

    with open("Inventory.txt", "r") as f:
        filedata = f.readlines()

    replace = ""
    line_number = 0
    count = 0
    f = open("Inventory.txt","r")
    file = f.read().split('\n')
    for i, line in enumerate(file):
        if Description in line:
            for b in file[i+1:i+2]:
                value = int(b)
                change = value - (Quantity)
                replace = b.replace(b, str(change))
                line_number = count
            count = i + 1      
    f.close()
    
    filedata[count] = replace + "\n"

    with open("Inventory.txt", "w") as f:
        for line in filedata:
            f.write(line)
    print("Outbound Completed")

def Inventory_Menu():
    Header()
    print("Inventory Menu :")
    print("[1] - Dispaly Inventory")
    print("[2] - Add New Inventory")
    print("[0] - To Go Back Main Menu")
    Inventory_Menu = input("Input Trsaction Code : ")
    if Inventory_Menu == '1':
        Display_Inventory()
    elif Inventory_Menu == '2':
        Add_New_Inventory()
    elif Inventory_Menu == '0':
        import Main_Program
        Main_Program.Main_Menu()
    else:
        print("Invalid Transaction Code")

def Add_New_Inventory():
    Header()
    Item_Type = input("Item Type   : ")
    Description = input("Description : ")
    Quantity = input("Quantity    : ")
    with open("Inventory.txt","a") as file:
        file.write(Item_Type + "\n")
        file.write(Description + "\n")
        file.write(Quantity + "\n")
    print("Your Item Has Been Added")
    print("-"*28)
    Inventory_Menu()

def Display_Inventory():
    Header()
    with open("Inventory.txt", "r") as Inv:
        item_type = Inv.readline()
        while item_type != '':
            item_description = Inv.readline()
            item_quantity = Inv.readline()
            item_type = item_type.rstrip("\n")
            item_description = item_description.rstrip("\n")
            item_quantity = item_quantity.rstrip("\n")
            print("Item Type   : ",item_type)
            print("Description : ",item_description)
            print("Quantity    : ",item_quantity)
            item_type = Inv.readline()
        Inventory_Menu()
 
def Header():
    print("-"*28)
    print("BASIC WAREHOUSE SYSTEM".center(28))
    print("MEDICINE DEPARTMENT STORE".center(28))
    print("-"*28)
